const db = require('../database/models');
const sequelize = db.sequelize;
const { validationResult } = require("express-validator")

const moviesController = {
    'list': (req, res) => {
        db.Movie.findAll()
            .then(movies => {
                console.log(movies)
                res.render('moviesList.ejs', {movies: movies})
            })
    },
    'new': (req, res) => {
        db.Movie.findAll({order: [["release_date", "DESC"]], limit: 5})
            .then(movies => {
                res.render('newestMovies.ejs', {movies: movies})
            })
    },
    'recomended': (req, res) => {
        db.Movie.findAll({where:{rating: {[db.Sequelize.Op.gt]: 7}}, order: [["rating", "DESC"]]})
            .then(movies => {
                res.render('recommendedMovies.ejs', {movies: movies})
            })
    },
    'detail': (req, res) => {
        db.Movie.findByPk(req.params.id, {include: [{association: 'genres'}, {association: 'actors'}]})
            .then(movie => {
                console.log(movie)
                res.render('moviesDetail.ejs', {movie: movie})
            })
    },
    'add': (req, res) => {
        db.Genre.findAll()
            .then(genres => {
                res.render('moviesAdd.ejs', {genres: genres})
            })
    },
    'create': (req, res) => {
        const resultValidation = validationResult(req);
        db.Genre.findAll()
            .then(genres => {
                if (resultValidation.errors.length>0) {
                    res.render('moviesAdd.ejs', {genres: genres, errors: resultValidation.mapped()})
                }
                else {
                    let movie = {
                        title: req.body.title,
                        rating: req.body.rating,
                        awards: req.body.awards,
                        release_date: req.body.release_date,
                        length: req.body.length,
                        genre_id: req.body.genre_id,
                        image: req.file.filename
                    }
                    db.Movie.create(movie)
                    res.redirect('/')
                }
            })
        
        
    },
    'edit': (req, res) => {
        let movie = db.Movie.findByPk(req.params.id, {include: [{association: 'genres'}]});
        let genres = db.Genre.findAll();
        Promise.all([movie, genres])
            .then(([Movie, Genres]) => {
                return res.render('moviesEdit.ejs', {Movie: Movie, Genres:Genres})
            })
            .catch(error => res.send(error));

        
    },
    'update': (req, res) => {
        let movie = {
            title: req.body.title,
            rating: req.body.rating,
            awards: req.body.awards,
            release_date: req.body.release_date,
            length: req.body.length,
            genre_id: req.body.genre_id
        }
        console.log(movie)
        db.Movie.update(movie, {where:{id: req.params.id}})
        res.redirect('/movies')
    },
    'deleteView': (req, res) => {
        db.Movie.findByPk(req.params.id)
            .then(Movie => {
                res.render('moviesDelete.ejs', {Movie: Movie})
            })
    },
    'delete': (req, res) => {
        db.Movie.destroy({where:{id: req.params.id}})
        res.redirect('/movies')
    }
}

module.exports = moviesController;