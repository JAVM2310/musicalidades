module.exports = (sequelize, dataTypes) => {
    let alias = 'Movie';
    let cols = {
        id: {
            type: dataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        title: {
            type: dataTypes.STRING
        },
        rating: {
            type: dataTypes.INTEGER
        },
        awards : {
            type: dataTypes.INTEGER
        },
        created_at: {
            type: dataTypes.DATE
        },
        updated_at: {
            type: dataTypes.DATE
        },
        release_date: {
            type: dataTypes.DATE
        },
        length: {
            type: dataTypes.INTEGER
        },
        image: {
            type: dataTypes.STRING(255)
        }

    };
    let config = {
        tableName: 'movies',
        timestamps: false
    };
    const Movie = sequelize.define(alias, cols, config);

    Movie.associate = function(models) {

        Movie.belongsTo(models.Genre, {
            as: 'genres',
            foreignKey: "genre_id"
        })


        Movie.belongsToMany(models.Actor, {
            as: "actors",
            through: "actor_movie", /// Tabla intermedia
            foreignKey: "movie_id", /// Es el FK del modelo en el que estas (en la tabla intermedia de la bd)
            otherKey: "actor_id", /// Es el FK del otro modelo (en la tabla intermedia de la bd)
            timestamps: false
        })


    }

    return Movie
}