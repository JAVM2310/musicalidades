const express = require('express');
const { route } = require('.');
const router = express.Router();
const moviesController = require('../controllers/moviesController');
const uploadFile = require("../middlewares/multerMiddlewares")
const validations = require("../middlewares/validationsMovies")

router.get('/movies', moviesController.list);
router.get('/movies/new', moviesController.new);
router.get('/movies/recommended', moviesController.recomended);
router.get('/movies/detail/:id', moviesController.detail);

/// CREATE 
router.get('/movies/add', moviesController.add);
router.post('/movies/create', uploadFile.single("image"), validations ,moviesController.create)

/// UPDATE
router.get('/movies/edit/:id', moviesController.edit);
router.put('/movies/update/:id', moviesController.update)

/// DESTROY -- NO SE USA PRACTICAMENTE
router.get('/movies/delete/:id', moviesController.deleteView) 
router.delete('/movies/delete/:id', moviesController.delete)

module.exports = router;